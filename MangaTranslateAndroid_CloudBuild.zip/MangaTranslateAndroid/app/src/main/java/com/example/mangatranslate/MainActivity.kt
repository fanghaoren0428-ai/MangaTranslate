package com.example.mangatranslate

import android.app.Activity
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import android.graphics.Typeface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.TextRecognition
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var status: TextView
    private lateinit var overlay: OverlayView
    private var translated = mutableListOf<OverlayView.Label>()
    private var mode = "Japanese"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(18,22,31)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8,8,8,8) }
        urlBox = EditText(this).apply {
            hint = "粘贴漫画网页链接"; setSingleLine(true); textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setBackgroundColor(Color.rgb(37,44,58))
            layoutParams = LinearLayout.LayoutParams(0, 48, 1f)
        }
        val go = Button(this).apply { text = "打开"; setOnClickListener { loadUrl() } }
        bar.addView(urlBox); bar.addView(go); root.addView(bar)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val lang = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("日文","韩文","中文"))
            setSelection(0); setOnItemSelectedListener(object: android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, position: Int, id: Long) {
                    mode = listOf("Japanese","Korean","Chinese")[position]
                }
            })
        }
        val scan = Button(this).apply { text = "识别并翻译当前屏幕"; setOnClickListener { captureAndTranslate() } }
        val clear = Button(this).apply { text = "清除中文"; setOnClickListener { translated.clear(); overlay.invalidate() } }
        controls.addView(lang); controls.addView(scan); controls.addView(clear); root.addView(controls)
        status = TextView(this).apply { text = "打开漫画网页后，点“识别并翻译当前屏幕”。首次识别需联网下载模型。"; setTextColor(Color.LTGRAY); textSize = 12f; setPadding(10,4,10,4) }
        root.addView(status)
        val frame = FrameLayout(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webViewClient = WebViewClient()
        }
        overlay = OverlayView()
        frame.addView(web, FrameLayout.LayoutParams(-1,-1))
        frame.addView(overlay, FrameLayout.LayoutParams(-1,-1))
        root.addView(frame, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        urlBox.setText("https://")
    }
    private fun loadUrl() {
        var u = urlBox.text.toString().trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        if (!u.startsWith("https://")) { status.text = "为安全起见，仅允许 HTTPS 网站"; return }
        web.loadUrl(u)
        status.text = "正在打开网页…"
    }
    private fun captureAndTranslate() {
        status.text = "正在截取当前可见页面…"
        web.post {
            try {
                val bmp = Bitmap.createBitmap(web.width, web.height, Bitmap.Config.ARGB_8888)
                web.draw(Canvas(bmp))
                recognize(bmp)
            } catch (e: Exception) { status.text = "截屏失败：" + e.localizedMessage }
        }
    }
    private fun recognize(bitmap: Bitmap) {
        val recognizer = when(mode) {
            "Korean" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            "Chinese" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        }
        status.text = "正在识别文字…"
        recognizer.process(InputImage.fromBitmap(bitmap,0))
            .addOnSuccessListener { result -> translateBlocks(result, bitmap.width, bitmap.height) }
            .addOnFailureListener { status.text = "文字识别失败：" + it.localizedMessage }
    }
    private fun translateBlocks(result: Text, w: Int, h: Int) {
        val blocks = result.textBlocks.flatMap { block -> block.lines }.take(40)
        if (blocks.isEmpty()) { status.text = "没有识别到文字。可尝试放大漫画或换一种识别语言。"; return }
        status.text = "识别到 ${blocks.size} 行，正在翻译…"
        translated.clear()
        overlay.invalidate()
        thread {
            val labels = mutableListOf<OverlayView.Label>()
            for (line in blocks) {
                val rect = line.boundingBox ?: continue
                val tr = translateText(line.text) ?: continue
                labels.add(OverlayView.Label(
                    rect.left.toFloat()/w, rect.top.toFloat()/h,
                    rect.right.toFloat()/w, rect.bottom.toFloat()/h, tr
                ))
            }
            runOnUiThread {
                translated = labels
                overlay.labels = translated
                overlay.invalidate()
                status.text = "完成：已覆盖 ${labels.size} 处文字。提示：当前为基础覆盖，复杂气泡和竖排文字可能需要手动校正。"
            }
        }
    }
    private fun translateText(text: String): String? {
        return try {
            val q = URLEncoder.encode(text, "UTF-8")
            val url = URL("https://api.mymemory.translated.net/get?q=$q&langpair=${if(mode=="Korean") "ko" else "ja"}|zh-CN")
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 10000
            c.setRequestProperty("User-Agent","MangaTranslateAndroid/0.1")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            JSONObject(body).optJSONObject("responseData")?.optString("translatedText")?.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
    }
    inner class OverlayView : View(this) {
        data class Label(val l: Float, val t: Float, val r: Float, val b: Float, val text: String)
        var labels: List<Label> = emptyList()
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif",Typeface.NORMAL) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            labels.forEach { item ->
                val left=item.l*width; val top=item.t*height; val right=item.r*width; val bottom=item.b*height
                val pad=5f
                canvas.drawRoundRect(RectF(left-pad,top-pad,right+pad,bottom+pad),8f,8f,bg)
                val maxWidth=(right-left).coerceAtLeast(28f)
                var size=((bottom-top)*0.78f).coerceIn(12f,28f)
                fg.textSize=size
                val lines = wrap(item.text, maxWidth, fg)
                val lineHeight=size*1.12f
                val totalH=lines.size*lineHeight
                if (top-pad+totalH > height) size=12f
                fg.textSize=size
                val lines2=wrap(item.text,maxWidth,fg)
                var y=(top+bottom)/2f - (lines2.size-1)*size*0.56f + size*0.35f
                lines2.forEach { s -> canvas.drawText(s, (left+right)/2f, y, fg); y += size*1.12f }
            }
        }
        private fun wrap(s: String, max: Float, p: Paint): List<String> {
            val out= mutableListOf<String>(); var cur=""
            s.forEach { ch ->
                val next=cur+ch
                if(cur.isNotEmpty() && p.measureText(next)>max) { out.add(cur); cur="$ch" } else cur=next
            }
            if(cur.isNotEmpty()) out.add(cur)
            return out
        }
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean = false
    }
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
